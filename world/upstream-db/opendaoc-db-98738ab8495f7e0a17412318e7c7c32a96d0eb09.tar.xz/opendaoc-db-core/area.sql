/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE TABLE IF NOT EXISTS `area` (
  `TranslationId` text DEFAULT NULL,
  `Description` text NOT NULL,
  `X` int(11) NOT NULL DEFAULT 0,
  `Y` int(11) NOT NULL DEFAULT 0,
  `Z` int(11) NOT NULL DEFAULT 0,
  `Radius` int(11) NOT NULL DEFAULT 0,
  `Region` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ClassType` text DEFAULT NULL,
  `CanBroadcast` tinyint(1) NOT NULL DEFAULT 0,
  `Sound` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `CheckLOS` tinyint(1) NOT NULL DEFAULT 0,
  `Points` text DEFAULT NULL,
  `LastTimeRowUpdated` datetime NOT NULL DEFAULT '2000-01-01 00:00:00',
  `Area_ID` varchar(255) NOT NULL,
  PRIMARY KEY (`Area_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

REPLACE INTO `area` (`TranslationId`, `Description`, `X`, `Y`, `Z`, `Radius`, `Region`, `ClassType`, `CanBroadcast`, `Sound`, `CheckLOS`, `Points`, `LastTimeRowUpdated`, `Area_ID`) VALUES
	(NULL, 'Ardagh', 351502, 553380, 5103, 1750, 200, 'DOL.GS.Area+Circle', 0, 8, 0, NULL, '2022-05-04 03:33:41', '0293f234-ad7c-4362-907f-9d46305cdb8a'),
	(NULL, 'Adibard\'s Retreat', 473165, 628021, 2048, 2500, 1, 'DOL.GS.Area+Circle', 0, 6, 0, NULL, '2022-05-04 15:04:47', '0320973a-28f5-4ea6-ba05-b365efd2c886'),
	(NULL, 'Mardagh', 352917, 517048, 5081, 1500, 200, 'DOL.GS.Area+Circle', 0, 11, 0, NULL, '2022-05-04 03:29:53', '0425db44-5046-479d-960f-f616c05eb973'),
	(NULL, 'Camelot Bind Area', 35564, 27157, 8448, 15000, 10, 'DOL.GS.Area+BindArea', 1, 0, 0, NULL, '2000-01-01 00:00:00', '06307389-7762-4d8e-a3c3-4aeee1683df6'),
	(NULL, 'Vetusta Abbey', 505096, 495673, 2432, 2500, 1, 'DOL.GS.Area+Circle', 0, 7, 0, NULL, '2022-05-04 15:14:04', '06b283a2-73b6-4850-8c8a-769d2e98fd44'),
	(NULL, 'Basar', 338739, 444751, 5077, 1500, 200, 'DOL.GS.Area+Circle', 0, 0, 0, NULL, '2022-05-04 17:30:00', '0878525c-45c6-4db0-8317-66561c8221ee'),
	(NULL, 'Cornwall Station', 408357, 652122, 4944, 1500, 1, 'DOL.GS.Area+Circle', 0, 16, 0, NULL, '2022-05-04 15:08:18', '1d62c524-aa07-4275-a38f-c0910e1c4481'),
	(NULL, 'Culraid', 298535, 687614, 5069, 1000, 200, 'DOL.GS.Area+Circle', 0, 11, 0, NULL, '2022-05-04 03:41:11', '25032c4e-8031-45e1-a039-f4f1bf7cfd91'),
	(NULL, 'Jordheim Bind Area', 33344, 32137, 8469, 15000, 101, 'DOL.GS.Area+BindArea', 1, 0, 0, NULL, '2000-01-01 00:00:00', '264f34dd-09fb-4996-b379-3c36030dbeef'),
	(NULL, 'Neasan\'s Land', 344419, 551942, 5374, 1000, 200, 'DOL.GS.Area+Circle', 0, 33, 0, NULL, '2022-05-04 03:51:50', '27caec38-1540-4956-9653-d88ce7a9b93f'),
	(NULL, 'Audliten', 727221, 760595, 5754, 4500, 100, 'DOL.GS.Area+Circle', 0, 3, 0, NULL, '2022-05-04 04:33:08', '3416f202-49fc-4808-92a3-e795036943a6'),
	(NULL, 'Godrborg', 597394, 304815, 8088, 2000, 163, 'DOL.GS.Area+Circle', 1, 0, 0, NULL, '2000-01-01 00:00:00', '36147893-ce79-4a9f-9b13-38f63c76dcdd'),
	(NULL, 'GM', 331467, 453362, 8112, 200, 73, 'DOL.GS.Area+BindArea', 0, 0, 0, NULL, '2022-06-15 19:14:49', '38edfa38-f95c-4313-bc4e-29a163190b2d'),
	(NULL, 'Nalliten', 770510, 837379, 4624, 2000, 100, 'DOL.GS.Area+Circle', 0, 1, 0, NULL, '2022-05-04 04:42:08', '3ca60e51-b12f-456f-8c15-5871e3ff37eb'),
	(NULL, 'Huginfel', 711535, 783908, 4672, 3500, 100, 'DOL.GS.Area+Circle', 0, 3, 0, NULL, '2022-05-04 04:37:52', '3d598d44-4b5a-4625-8739-fcc82e074134'),
	(NULL, 'Haggerfel', 805731, 701535, 4960, 1500, 100, 'DOL.GS.Area+Circle', 0, 2, 0, NULL, '2022-05-04 04:15:11', '3ed9ed1e-a1be-4aa0-9c06-a30a82b26ce5'),
	(NULL, 'Connla', 295946, 641999, 4848, 2000, 200, 'DOL.GS.Area+Circle', 0, 33, 0, NULL, '2022-05-04 03:37:44', '41320cee-e3d0-4775-9bb0-f83a2a51eaca'),
	(NULL, 'Brynach', 409987, 528096, 2112, 1000, 200, 'DOL.GS.Area+Circle', 0, 0, 0, NULL, '2022-05-04 17:33:09', '42b587e3-e48f-4a89-a0d4-a00534b4ae2e'),
	(NULL, 'Druim Ligen', 333229, 419539, 5336, 3500, 200, 'DOL.GS.Area+Circle', 0, 0, 0, NULL, '2022-01-05 23:45:30', '4398fb9c-3cb0-471a-9066-723364a21b78'),
	(NULL, 'Cotswold Village', 560368, 511740, 2280, 2500, 1, 'DOL.GS.Area+Circle', 0, 6, 0, NULL, '2022-05-04 04:59:38', '48f137d8-771f-4c98-a3bd-a85505530b35'),
	(NULL, 'Caer Witrin', 437031, 650943, 2448, 1000, 1, 'DOL.GS.Area+Circle', 0, 0, 0, NULL, '2022-05-04 15:06:30', '540db3b1-c53b-4908-893a-cb06c8744f3a'),
	(NULL, 'Fort Atla', 749260, 815624, 4408, 4000, 100, 'DOL.GS.Area+Circle', 0, 2, 0, NULL, '2022-05-04 04:40:01', '5783ee28-0d53-4381-a848-5f7178ca3e83'),
	(NULL, 'Prydwen Keep', 574139, 530505, 3317, 2000, 1, 'DOL.GS.Area+Circle', 0, 21, 0, NULL, '2022-05-04 13:05:17', '6cdcd5b4-6944-4572-b4bf-7b9753998252'),
	(NULL, 'Crair Treflan', 373562, 572957, 8040, 2500, 163, 'DOL.GS.Area+Circle', 1, 0, 0, NULL, '2000-01-01 00:00:00', '71149ce9-7667-4440-9479-9dc8f8a9959d'),
	(NULL, 'Ludlow Village', 530970, 479121, 2200, 2000, 1, 'DOL.GS.Area+Circle', 0, 6, 0, NULL, '2022-05-04 13:08:23', '734ed8e4-a363-4da6-bb1a-87c09adfbede'),
	(NULL, 'Event Safe Zone', 354940, 382292, 5131, 60000, 27, 'DOL.GS.Area+SafeArea', 0, 0, 0, NULL, '2021-11-18 19:25:13', '764502d6-19de-4e93-8a78-703f364b9586'),
	(NULL, 'Lethantis Association', 497482, 587753, 4154, 1750, 1, 'DOL.GS.Area+Circle', 0, 0, 0, NULL, '2022-05-04 14:56:27', '784f87a5-d738-4371-b058-b60f40dff115'),
	(NULL, 'Vindsaul Faste', 704022, 738009, 5704, 3500, 100, 'DOL.GS.Area+Circle', 0, 23, 0, NULL, '2022-01-05 23:47:18', '7aa6f7b2-fdda-41aa-9b8b-703b00b032b9'),
	(NULL, 'Tir Urphost', 248267, 437989, 5705, 1000, 200, 'DOL.GS.Area+Circle', 0, 10, 0, NULL, '2022-05-04 03:25:04', '7d18f6d6-ac10-4702-a03d-56121052d338'),
	(NULL, 'Mag Mell', 346463, 490663, 5330, 1750, 200, 'DOL.GS.Area+Circle', 0, 26, 0, NULL, '2022-05-04 03:27:23', '82a0af77-b5cc-4774-9c0a-73350b92f5df'),
	(NULL, 'Snowdonia Fortress', 528451, 358290, 8320, 3500, 1, 'DOL.GS.Area+Circle', 0, 0, 0, NULL, '2022-01-05 23:48:30', '8b2d90af-c5c0-4df2-9f7f-962044734ae2'),
	(NULL, 'Caille', 420684, 516178, 1824, 2000, 200, 'DOL.GS.Area+Circle', 0, 0, 0, NULL, '2022-05-04 17:32:29', '8cacd18e-d62a-4cc5-8629-4d500d9c90cd'),
	(NULL, 'Tir na mBeo', 344082, 528432, 5448, 2500, 200, 'DOL.GS.Area+Circle', 0, 9, 0, NULL, '2022-05-04 03:31:36', '92e403ea-3e45-4067-8dd0-b01ce7a54bbc'),
	(NULL, 'Siopa', 361354, 750434, 4944, 1000, 200, 'DOL.GS.Area+Circle', 0, 33, 0, NULL, '2022-05-04 03:45:48', '93ca4665-9460-42e4-97ea-edd6ba6d87f1'),
	(NULL, 'Swanton Keep', 510845, 381386, 7992, 1000, 1, 'DOL.GS.Area+Circle', 0, 15, 0, NULL, '2022-05-04 14:28:41', '93faaf4e-f07b-4534-a31b-d8cbd4bdbcad'),
	(NULL, 'Druim Cain', 421166, 484998, 1976, 3500, 200, 'DOL.GS.Area+Circle', 0, 10, 0, NULL, '2022-01-05 23:46:07', '966701c7-5dd4-4a1b-bace-af0812145707'),
	(NULL, 'Humberton Castle', 504281, 474493, 2788, 2000, 1, 'DOL.GS.Area+Circle', 0, 13, 0, NULL, '2022-05-04 14:24:48', '983f85b3-d546-4cab-b04b-df438129fe02'),
	(NULL, 'Caer Ulfwych', 521295, 617155, 1793, 2000, 1, 'DOL.GS.Area+Circle', 0, 0, 0, NULL, '2022-05-04 14:47:46', '9cf39343-e63f-44e8-ab9e-6004ef94bf36'),
	(NULL, 'Svasud Faste', 766235, 669173, 5736, 3500, 100, 'DOL.GS.Area+Circle', 0, 0, 0, NULL, '2022-01-05 23:46:47', '9d9613dc-072a-4c43-a6c3-2641e738f6fc'),
	(NULL, 'Fort Veldon', 798858, 677593, 5650, 2500, 100, 'DOL.GS.Area+Circle', 0, 23, 0, NULL, '2022-05-04 04:18:36', '9e2d29df-71ae-4e6c-b8f2-61cfed8d6979'),
	(NULL, 'Tir na Nog Bind Area', 29825, 33165, 7916, 15000, 201, 'DOL.GS.Area+BindArea', 1, 0, 0, NULL, '2000-01-01 00:00:00', '9e560b3e-10f0-4d12-afa3-72a8f72bc459'),
	(NULL, 'Campacorentin Station', 493703, 592523, 1808, 1750, 1, 'DOL.GS.Area+Circle', 0, 21, 0, NULL, '2022-05-04 14:55:14', 'a073badb-af78-4026-aea8-1ad477ce5d9d'),
	(NULL, 'Seithkona Circle', 742648, 911351, 5979, 2500, 100, 'DOL.GS.Area+Circle', 0, 0, 0, NULL, '2022-05-13 23:40:23', 'a6f7cd28-76b8-498a-ad65-40314da58f63'),
	(NULL, 'Howth', 341876, 591998, 5861, 2000, 200, 'DOL.GS.Area+Circle', 0, 10, 0, NULL, '2022-05-04 03:35:22', 'a89bab9f-02b3-47f8-a120-772764e3c2a9'),
	(NULL, 'Humberton Village', 508440, 477188, 2372, 2000, 1, 'DOL.GS.Area+Circle', 0, 12, 0, NULL, '2022-05-04 13:15:05', 'a9728bf6-e7c0-4e2e-a4c4-33bf7260c552'),
	(NULL, 'Aalid Feie', 310486, 351988, 6062, 6000, 181, 'DOL.GS.Area+Circle', 1, 0, 0, NULL, '2000-01-01 00:00:00', 'aalid_feie'),
	(NULL, 'Ardee', 340873, 468276, 5200, 1750, 200, 'DOL.GS.Area+Circle', 0, 11, 0, NULL, '2022-05-04 03:13:08', 'ab324338-3335-4236-bec9-b5c10b4997c2'),
	(NULL, 'Aegirhamn', 291043, 354886, 3868, 5000, 151, 'DOL.GS.Area+Circle', 1, 0, 0, NULL, '2000-01-01 00:00:00', 'aegirhamn'),
	(NULL, 'Gna Faste', 787865, 904821, 4744, 1500, 100, 'DOL.GS.Area+Circle', 0, 2, 0, NULL, '2022-05-04 04:45:49', 'b9b7bc19-50ed-46cf-80d5-c92ee9937d14'),
	(NULL, 'Galplen', 797304, 893426, 4767, 2500, 100, 'DOL.GS.Area+Circle', 0, 1, 0, NULL, '2022-05-04 04:47:20', 'ba4adc15-bfbf-4635-a8c8-4249b4c7122d'),
	(NULL, 'Castle Sauvage', 585085, 477504, 2600, 3500, 1, 'DOL.GS.Area+Circle', 0, 0, 0, NULL, '2022-01-05 23:47:51', 'bef3d815-6acc-4473-9557-472381bd9938'),
	(NULL, 'Catterick Hamlet', 677251, 568214, 8088, 2000, 163, 'DOL.GS.Area+Circle', 1, 6, 0, NULL, '2000-01-01 00:00:00', 'bf84dfc0-b6fc-4a68-abaa-429ddc73f8a6'),
	(NULL, 'Bjarken', 287715, 302919, 4160, 4000, 151, 'DOL.GS.Area+Circle', 1, 0, 0, NULL, '2000-01-01 00:00:00', 'bjarken'),
	(NULL, 'Snowdonia Station', 523035, 408818, 4353, 1000, 1, 'DOL.GS.Area+Circle', 0, 16, 0, NULL, '2022-05-04 14:27:11', 'c19b8d31-0c1f-419a-91bf-8caca84a6b92'),
	(NULL, 'Dvalin', 725166, 789948, 4600, 1500, 100, 'DOL.GS.Area+Circle', 0, 2, 0, NULL, '2022-05-04 04:35:17', 'c28979dd-73cc-4331-b8e2-ba1183ba595b'),
	(NULL, 'thehiddenlair', 31840, 37818, 21396, 5830, 326, 'DOL.GS.Area+Circle', 0, 0, 0, '', '2000-01-01 00:00:00', 'c4e4e337-f8f1-421f-8198-2d7802c258d9'),
	(NULL, 'Caer Diogel', 402771, 502879, 4680, 4000, 51, 'DOL.GS.Area+Circle', 1, 0, 0, NULL, '2000-01-01 00:00:00', 'caer_diogel'),
	(NULL, 'Caer Gothwaite', 534958, 548813, 4755, 4000, 51, 'DOL.GS.Area+Circle', 1, 6, 0, NULL, '2000-01-01 00:00:00', 'caer_gothwaite'),
	(NULL, 'Alainn Bin', 404610, 765704, 4944, 1750, 200, 'DOL.GS.Area+Circle', 0, 10, 0, NULL, '2022-05-04 03:47:00', 'd54f21ef-42b2-47ce-8adf-74b3ec05eaff'),
	(NULL, 'West Downs', 577635, 556980, 2191, 1500, 1, 'DOL.GS.Area+Circle', 0, 7, 0, NULL, '2022-05-04 14:31:51', 'df01dfc3-5e52-425c-acf0-2f3a583114f8'),
	(NULL, 'Droighaid', 379827, 420963, 5528, 5000, 181, 'DOL.GS.Area+Circle', 1, 0, 0, NULL, '2000-01-01 00:00:00', 'droighaid'),
	(NULL, 'Innis Carthaig', 334820, 719979, 4409, 1500, 200, 'DOL.GS.Area+Circle', 0, 10, 0, NULL, '2022-05-04 03:42:59', 'e3e9997b-7a39-43fe-974b-9b4dcf144ca9'),
	(NULL, 'Mularn', 804091, 724155, 4680, 4000, 100, 'DOL.GS.Area+Circle', 0, 3, 0, NULL, '2022-05-04 04:11:04', 'e69e4724-eae7-4441-b76e-b2dcd740538c'),
	(NULL, 'Ceannoi', 325877, 677873, 5047, 1000, 200, 'DOL.GS.Area+Circle', 0, 8, 0, NULL, '2022-05-04 03:39:31', 'f23629f5-0ede-4c65-9d13-48c65effcf60'),
	(NULL, 'Event Safe Zone', 341926, 384995, 5387, 30000, 27, 'DOL.GS.Area+SafeArea', 0, 0, 0, NULL, '2021-11-19 17:38:15', 'f8e4f280-b46e-467a-b59f-88f5774823c7'),
	(NULL, 'Vasudheim', 774405, 755429, 4600, 3000, 100, 'DOL.GS.Area+Circle', 0, 4, 0, NULL, '2022-05-04 04:27:01', 'fb777813-920e-494e-8cdd-e10085f07267'),
	(NULL, 'Fort Gwyntell', 426905, 416817, 5712, 3000, 51, 'DOL.GS.Area+Circle', 1, 0, 0, NULL, '2000-01-01 00:00:00', 'fort_gwyntell'),
	(NULL, 'Gothwaite Harbor', 525023, 542126, 3168, 4000, 51, 'DOL.GS.Area+Circle', 1, 6, 0, NULL, '2000-01-01 00:00:00', 'gothwaite_harbour'),
	(NULL, 'Grove of Domnann', 423149, 444401, 6062, 4000, 181, 'DOL.GS.Area+Circle', 1, 0, 0, NULL, '2000-01-01 00:00:00', 'grove_of_domnann'),
	(NULL, 'Hagall', 379260, 385996, 7752, 3500, 151, 'DOL.GS.Area+Circle', 1, 0, 0, NULL, '2000-01-01 00:00:00', 'hagall'),
	(NULL, 'Knarr', 302561, 433648, 3212, 3500, 151, 'DOL.GS.Area+Circle', 1, 0, 0, NULL, '2000-01-01 00:00:00', 'knarr'),
	(NULL, 'Necht', 429890, 317886, 1832, 4000, 181, 'DOL.GS.Area+Circle', 1, 0, 0, NULL, '2000-01-01 00:00:00', 'necht'),
	(NULL, 'Wearyall Village', 435799, 493970, 3088, 4000, 51, 'DOL.GS.Area+Circle', 1, 0, 0, NULL, '2000-01-01 00:00:00', 'wearyall_village');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
